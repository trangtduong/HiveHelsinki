#include "ft_btree_extra.h"

void	ft_putstr(void *c)
{
	printf("%s\n", (char*)c);
}
