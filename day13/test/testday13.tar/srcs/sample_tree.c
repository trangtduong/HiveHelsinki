#include "ft_btree_extra.h"

t_btree	*sample_tree(void)
{
	t_btree	*root;

	root = btree_create_node("5");
	root->left = btree_create_node("3");
	root->right = btree_create_node("7");
	root->left->left = btree_create_node("1");
	root->left->right = btree_create_node("4");
	root->right->left = btree_create_node("6");
	root->right->right = btree_create_node("9");
	return (root);
}

/*
				5
			3		7
		1   	4 6 	9

*/

5 3 7 1 4 6 9
0 1 1 2 2 2 2
|
first